document.addEventListener('DOMContentLoaded', () => {

    // 2. Header Scroll state
    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // 3. Mobile Menu Toggle
    const mobileBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileBtn && navLinks) {
        mobileBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            const icon = mobileBtn.querySelector('i');
            if (navLinks.classList.contains('active')) {
                icon.className = 'fa-solid fa-xmark';
                document.body.style.overflow = 'hidden';
            } else {
                icon.className = 'fa-solid fa-bars';
                document.body.style.overflow = '';
            }
        });

        // Close menu on link click
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                if (mobileBtn.querySelector('i')) {
                    mobileBtn.querySelector('i').className = 'fa-solid fa-bars';
                }
                document.body.style.overflow = '';
            });
        });
    }

    // 4. Scroll Reveal Animations (Intersection Observer)
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.15
    };

    const fadeObsever = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target); // optional: run once
            }
        });
    }, observerOptions);

    const fadeElements = document.querySelectorAll('.fade-up');
    fadeElements.forEach(el => fadeObsever.observe(el));

    // ======================================
    // INTERACTIVE UI LOGIC
    // ======================================

    // 1. Swiper Carousel Initialization
    if(document.querySelector('.hero-swiper')) {
        const swiper = new Swiper('.hero-swiper', {
            loop: true,
            effect: 'fade', // professional enterprise transition
            autoplay: {
                delay: 6000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            parallax: true,
            speed: 1000
        });
    }

    // 2. Stats Fun-Fact Counter Logic
    const statsContainer = document.getElementById('statsGrid');
    const statNumbers = document.querySelectorAll('.stat-number');
    let hasCounted = false;

    if(statsContainer && statNumbers.length > 0) {
        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if(entry.isIntersecting && !hasCounted) {
                    hasCounted = true;
                    statNumbers.forEach(stat => {
                        const target = +stat.getAttribute('data-target');
                        const speed = 100; // lower is faster
                        
                        const updateCount = () => {
                            const current = +stat.innerText;
                            const increment = target / speed;

                            if(current < target) {
                                stat.innerText = Math.ceil(current + increment);
                                setTimeout(updateCount, 15);
                            } else {
                                stat.innerText = target;
                                if(target > 200) stat.innerText += "+";
                            }
                        };
                        updateCount();
                    });
                }
            });
        }, { threshold: 0.3 });
        
        counterObserver.observe(statsContainer);
    }

    // 3. Portfolio Isotope-style Filtering
    const filterBtns = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');

    if(filterBtns.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                // Manage active states
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                const filterValue = btn.getAttribute('data-filter');

                portfolioItems.forEach(item => {
                    if(filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                        item.classList.remove('hidden');
                        setTimeout(() => {
                            item.style.opacity = '1';
                            item.style.transform = 'scale(1)';
                        }, 10);
                    } else {
                        item.style.opacity = '0';
                        item.style.transform = 'scale(0.8)';
                        setTimeout(() => {
                            item.classList.add('hidden');
                        }, 300); // sync with CSS transition duration
                    }
                });
            });
        });
    }
});
